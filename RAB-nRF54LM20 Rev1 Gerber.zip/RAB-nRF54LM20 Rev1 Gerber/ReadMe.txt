
Project RAB-nRF54LM20 Rev1:
PCB dimensions 50.30x82.73mm.
2 Layers.
Thickness: 1.55mm FR4.
Mask color: PURPLE (MAGENTA).
Silkscreen color: WHITE.
Finish: Immersion Gold.